#include <stdio.h>
#include <stdlib.h>



int main()
{
    int numeros[10];
    int total = 0;
    for(int i=0; i<10; i++)
    {
         printf("Ingrese un numero: ");
         scanf("%d", &numeros[i]);
    }

    for(int i=0; i<10; i++)
    {
        printf("%d\n", numeros[i]);
    }

    for(int i=0; i<10; i++)
    {
        total += numeros[i];
    }

    printf("La suma de los 5 numeros ingresados es %d\n", total);
    return 0;
}
