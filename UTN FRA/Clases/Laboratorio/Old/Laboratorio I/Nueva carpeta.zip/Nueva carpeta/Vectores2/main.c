#include <stdio.h>
#include <stdlib.h>

int main()
{
    int vec[5]={12, -3, 56, 78, 23};

printf("Muestro el array como esta cargado\n\n");
     for(int i=0; i<5; i++)
    {
        printf(" %d", vec[i]);
    }

    printf("\n\n");

    printf("Muestro el array x2\n\n");

      for(int i=0; i<5; i++)
    {
       vec[i] = 2*vec[i];
    }

    printf("\n\n");

      for(int i=0; i<5; i++)
    {
        printf(" %d", vec[i]);
    }

    printf("\n\n");




    return 0;
}
