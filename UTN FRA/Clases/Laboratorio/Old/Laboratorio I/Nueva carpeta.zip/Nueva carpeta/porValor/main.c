#include <stdio.h>
#include <stdlib.h>

void funcionX(int*);

int main()
{

    int var = 5;

    printf("Var  vale %d\n", var);
    getch();

    funcionX(&var);

    printf("Por ultimo en main Var  vale %d\n", var);
    getch();


    return 0;
}

void funcionX(int* var){

printf("Var dentro de la funcion vale %d\n", *var);
getch();

*var = 10;

printf("Ahora var vale %d\n", *var);
getch();

}
