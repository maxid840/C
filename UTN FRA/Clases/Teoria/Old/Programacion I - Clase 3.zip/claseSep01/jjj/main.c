#include <stdio.h>
#include <stdlib.h>

int main()
{
    int numeros[] = {5, 7, 3, 8, 1, 2, 10, -4, 6, 4};
    int flag = 0;

    int num;

    printf("Ingrese el numero que quiere buscar: ");
    scanf("%d", &num);

    for(int i=0; i < 9; i++){

        if(numeros[i]== num){
            printf("El elemento buscado se encuentra en el vector en la posicion %d\n\n", i + 1);
            flag = 1;
            break;
        }


    }

    if(flag == 0){
        printf("\n No se encuentra el numero solicitado\n");
    }



    return 0;
}
