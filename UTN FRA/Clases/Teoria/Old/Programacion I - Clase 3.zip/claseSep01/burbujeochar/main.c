#include <stdio.h>
#include <stdlib.h>

int main()
{
    char numeros[] = {'d', 'A', 'h', 'a', 'l'};


    char aux;


    for(int i=0; i < 4; i++){
             for(int j= i+1; j < 5; j++){
                    if( numeros[i] > numeros[j])
                    {
                        aux = numeros[i];
                        numeros[i] = numeros[j];
                        numeros[j] = aux;
                    }
             }
    }

      for(int i=0; i<5; i++){
        printf("%c ", numeros[i]);
    }

    printf("\n\n");


    return 0;
}
