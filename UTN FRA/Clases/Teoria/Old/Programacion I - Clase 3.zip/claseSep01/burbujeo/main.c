#include <stdio.h>
#include <stdlib.h>

int main()
{
    int numeros[] = {5, 7, 3, 8, 1, 2, 10, -4, 6, 4};


    int aux;


    for(int i=0; i < 9; i++){
             for(int j= i+1; j < 10; j++){
                    if( numeros[i] < numeros[j])
                    {
                        aux = numeros[i];
                        numeros[i] = numeros[j];
                        numeros[j] = aux;
                    }
             }
    }

      for(int i=0; i<10; i++){
        printf("%d ", numeros[i]);
    }

    printf("\n\n");


    return 0;
}
