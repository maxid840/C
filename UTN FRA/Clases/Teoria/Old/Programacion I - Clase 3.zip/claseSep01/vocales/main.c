#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int validarVocal(char);
int main()
{
    char vec[5];
    char aux;

    for(int i=0; i<5; i++){
        printf("Ingrese una vocal: ");
        fflush(stdin);
        aux = getchar();

        while(validarVocal(aux)==0){

             printf("Error. Debe ingresar una vocal: ");
             fflush(stdin);
             aux = getchar();
        }
        vec[i] = aux;
    }

    printf("\nLos caracteres ingresados fueron: \n\n");

    for(int i=0; i<5; i++){
        printf("%c ", vec[i]);
    }

    printf("\n\n");

    return 0;
}


int validarVocal(char caracter){

    int esValido = 1;

    caracter = tolower(caracter);

    if(caracter != 'a' && caracter != 'e' && caracter != 'i' && caracter != 'o' && caracter != 'u'){
        esValido = 0;
    }

    return esValido;
}
