#include <stdio.h>
#include <stdlib.h>

int main()
{
    int leg[] = {38, 24, 18, 83, 57};
    int notas1[] = {10, 7, 2, 2, 5};
    int notas2[] = {4, 10, 2, 5, 4};
    float promedios[5];

    //Calculo los promedios

    for(int i=0; i<5; i++){
        promedios[i] = (float) (notas1[i] + notas2[i])/2;
    }

    // Muestro los datos
    printf(" Legajo  Nota_1  Nota_2  Promedio\n\n");
     for(int i=0; i<5; i++){
            printf("  %3d     %3d     %3d    %2.2f\n", leg[i], notas1[i], notas2[i], promedios[i]);
     }
     printf("\n\n");




    return 0;
}
